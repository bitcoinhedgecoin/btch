Development moved to https://gitlab.com/blacknet-ninja

https://bitcoinhedge.org/ aims to continue on BitcoinHedge chain.
